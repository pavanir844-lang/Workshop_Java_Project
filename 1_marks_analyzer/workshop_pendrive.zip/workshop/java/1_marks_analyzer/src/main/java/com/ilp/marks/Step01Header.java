package com.ilp.marks;

import java.util.*;

// ==============================================================
//  STEP 1 of 10  ·  Page title
// ==============================================================
//  WHAT:  Show a big title at the top of the page.
//  HINT:  <h1> is the biggest heading in HTML. Put your text between <h1> and </h1>.
//
//  HOW:   1. Find the line marked  👈 YOUR CODE HERE
//         2. Type the line shown just above it (in the comment)
//         3. Save the file:  Ctrl + S
//         4. Stop the app (Ctrl + C) and run it again:  mvn -o spring-boot:run
//         5. Refresh the browser page. Step 1 turns green when it is right.
//  Only change the marked line. Do not touch anything else.
// ==============================================================

public class Step01Header {

    public static String header() {
        // ✍️ Write this line:
        //    return "<h1>Marks Analyzer</h1>";
        return null; // 👈 YOUR CODE HERE (replace this line)
    }
}
